// gastubos/backend/src/utils/prisma.js
import { PrismaClient } from '@prisma/client'
export const prisma = new PrismaClient()
